#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "ft_abs.h"

int 	main(void)
{
	printf("%d",(ABS(-1)));
	return(0);
}

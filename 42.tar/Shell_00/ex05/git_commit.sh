git log --pretty=%H | head -n 5

find . -print | awk 'END {print NR}'
